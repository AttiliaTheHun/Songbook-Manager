    <meta charset="UTF-8">
    <meta name="theme-color" content="black" >
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="Zpěvník oddílu TOM Hraboši.">
    <link rel="stylesheet" type="text/css" href="./server-files/css/style.css">
    <link rel="stylesheet" href="../css/style.css">